--Add initial role
INSERT INTO `ssafy`.`role` (`role_id`, `role_name`) VALUES ('1', 'ROLE_USER');
INSERT INTO `ssafy`.`role` (`role_id`, `role_name`) VALUES ('2', 'ROLE_ADMIN');



